const btn = document.querySelector("#btn")
const div = document.querySelector("#div")

btn.addEventListener('click',function(){
    div.style.display = "block"
})