const input = document.querySelector("#input")
const btn = document.querySelector("#btn")
const body = document.body 

const arrColor = ['red', 'blue', 'green', 'black', 'white']



btn.addEventListener('click',function(){
    for(const el of arrColor){
        if(el === input.value){
            body.style.backgroundColor = el
            return 
        }
    }
    alert("enter valid color")
})



