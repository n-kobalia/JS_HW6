const input = document.querySelector("#input")
const btn = document.querySelector("#btn")




btn.addEventListener('click',()=>{
    let value = input.value
    const result = value.split(":")
    let sum
    for(const item of result){
        console.log(item)
    }
})


// ვეღარ მოვაწარი :((()))