const input = document.querySelector("#input")
const btn = document.querySelector("#btn")


btn.addEventListener('click',()=>{
    let value = input.value
    const result = value.split(":").map(Number)
    let sum = 0
    for(const item of result){
        sum += item
    }
    let average = sum / result.length
    console.log(`average is: ${average}`)
})


